//
//  ViewController.swift
//  Ass1_Coverting_Numbers
//
//  Created by Bharath Gandham on 9/11/19.
//  Copyright © 2019 Bharath Gandham. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var segmentContolSelection = 5
    var textFieldInput = ""
    var validationForDecimal = ""
    
    @IBOutlet weak var SegmentedControl: UISegmentedControl!
    @IBAction func SegRating(_ sender: UISegmentedControl) {
    segmentContolSelection=SegmentedControl.selectedSegmentIndex
    }
    
    @IBOutlet weak var lblToThrowErrors: UILabel!
    @IBOutlet weak var lblToThrowPositiveMessages: UILabel!
    @IBOutlet weak var textFieldName: UITextField!
    @IBOutlet weak var labelResult1: UILabel!
    @IBOutlet weak var labelResult2: UILabel!
    @IBOutlet weak var labelResult3: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
            textFieldName.becomeFirstResponder()
            //textFieldName.keyboardType = UIKeyboardType.phonePad
    }
    
    @IBAction func convertNumber(_ sender: Any) {
        textFieldInput=textFieldName.text!
        if 0...3 ~= segmentContolSelection{
        if textFieldInput==""{
            lblToThrowErrors.text="*Input a number to convert"
        }
        else
        {
        switch segmentContolSelection {
        case 0:
            do{
                let regex = try NSRegularExpression(pattern: ".*[^0-9 ].*", options: [])
                if regex.firstMatch(in: textFieldInput, options: [], range: NSMakeRange(0, textFieldInput.count)) != nil {
                    lblToThrowErrors.text="*Invalid Please Enter Decimal Input"

                } else {
                    lblToThrowPositiveMessages.text="Results for decimal input are as below"
                    lblToThrowErrors.text=nil
                    //textFieldName.keyboardType = UIKeyboardType.phonePad
                    let binaryResult = String(Int(textFieldInput,radix:10)!,radix:2)
                    let octalResult = String(Int(textFieldInput,radix:10)!,radix:8)
                    let hexaDecimalResult = String(Int(textFieldInput,radix:10)!,radix:16)
                    labelResult1.text="Binary Result is:"+binaryResult
                    labelResult2.text="Octal Result is:"+octalResult
                    labelResult3.text="HexaDecimal Result is:"+hexaDecimalResult
               }
            }
            catch {
                lblToThrowErrors.text="*Error"
            }
            
        case 1:
            do {
                let regex = try NSRegularExpression(pattern: ".*[^0-1 ].*", options: [])
                if regex.firstMatch(in: textFieldInput, options: [], range: NSMakeRange(0, textFieldInput.count)) != nil {
                    lblToThrowErrors.text="*Invalid Please Enter Binary Input"

                } else {
                    lblToThrowPositiveMessages.text="Results for Binary input are as below"
                    lblToThrowErrors.text=nil
                    let decimalResult = String(Int(textFieldInput,radix:2)!,radix:10)
                    let octalResult = String(Int(textFieldInput,radix:2)!,radix:8)
                    let hexaDecimalResult = String(Int(textFieldInput,radix:2)!,radix:16)
                    labelResult1.text="Decimal Result is:"+decimalResult
                    labelResult2.text="Octal Result is:"+octalResult
                    labelResult3.text="HexaDecimal Result is:"+hexaDecimalResult
                }
            }
            catch {
                    lblToThrowErrors.text="*Error"
            }
            
            break
        case 2:
            do {
            let regex = try NSRegularExpression(pattern: ".*[^0-7 ].*", options: [])
            if regex.firstMatch(in: textFieldInput, options: [], range: NSMakeRange(0, textFieldInput.count)) != nil {
                lblToThrowErrors.text="*Invalid Please Enter Octal Input"

            } else {
            lblToThrowPositiveMessages.text="Results for Octal input are as below"
            lblToThrowErrors.text=nil
            let decimalResult = String(Int(textFieldInput,radix:8)!,radix:10)
            let binaryResult = String(Int(textFieldInput,radix:8)!,radix:2)
            let hexaDecimalResult = String(Int(textFieldInput,radix:8)!,radix:16)
            labelResult1.text="Decimal Result is:"+decimalResult
            labelResult2.text="Binary Result is:"+binaryResult
            labelResult3.text="HexaDecimal Result is:"+hexaDecimalResult
                }
            }
                catch {
                        lblToThrowErrors.text="*Error"
                }
            break
        case 3:
            do {
            let regex = try NSRegularExpression(pattern: ".*[^A-Fa-f0-9 ].*", options: [])
            if regex.firstMatch(in: textFieldInput, options: [], range: NSMakeRange(0, textFieldInput.count)) != nil {
                lblToThrowErrors.text="*Invalid Please Enter Hexadecimal Input"

            } else {
            lblToThrowPositiveMessages.text="Results for Hexadecimal input are as below"
            lblToThrowErrors.text=nil
            let decimalResult = String(Int(textFieldInput,radix:16)!,radix:10)
            let binaryResult = String(Int(textFieldInput,radix:16)!,radix:2)
            let octalResult = String(Int(textFieldInput,radix:16)!,radix:8)
            labelResult1.text="Decimal Result is:"+decimalResult
            labelResult2.text="Binary Result is:"+binaryResult
            labelResult3.text="Octal Result Result is:"+octalResult
                }
            }
            catch {
                lblToThrowErrors.text="*Error"
            }
            break
        default:
            lblToThrowPositiveMessages.text=nil
            lblToThrowErrors.text="*Select a type to perform conversion"
            labelResult1.text="Result 1:"
            labelResult2.text="Result 2"
            labelResult3.text="Result 3"
        }
        }
        }
        else{
            lblToThrowErrors.text="*Select a type to perform conversion"
        }
    }
   
    @IBAction func clearResults(_ sender: Any) {
        self.SegmentedControl.selectedSegmentIndex = UISegmentedControl.noSegment
        segmentContolSelection = -1
        lblToThrowErrors.text=nil
        lblToThrowPositiveMessages.text=nil
        textFieldName.text=nil
        labelResult1.text="Result 1:"
        labelResult2.text="Result 2:"
        labelResult3.text="Result 3:"
    }
    
    @IBAction func keyboardScrollDownOnPressingReturn(_ sender: UITextField) {
        textFieldName.resignFirstResponder()
    }
    

    
}

